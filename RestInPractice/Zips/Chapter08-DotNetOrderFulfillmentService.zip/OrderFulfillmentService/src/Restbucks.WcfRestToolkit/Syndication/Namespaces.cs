﻿namespace Restbucks.WcfRestToolkit.Syndication
{
    public static class Namespaces
    {
        public const string Atom = "http://www.w3.org/2005/Atom";
        public const string AtomPub = "http://www.w3.org/2007/app";
    }
}